1. The code is design based on Python 3.7.4 , tensorflow 2.1.0 and Keras 2.3.1.
2. seq_preprocess.py: preprocess the gene sequences of coronavirus.The input file is 
the full sequences of RNA of coronavirus as fasta format and should be put into
the "fasta" folder.
3. predict_CCSI-DL.py: the main file to predict the cross-species transmission risk.The first 
parameter is the name of query file, the second parameter is the prediction confidence.
4. predicting_results.csv shows the result for the prediction of cross-species transmission.
The predicted label for 'H' means the phenotype of cross-species transmission while label for 'N' means not.
5. the models mentioned in our paper are saved as HDF5 files in "model" folder.
