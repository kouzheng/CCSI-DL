from keras.models import load_model
import tensorflow as tf
from seq_preprocess import preprocess
from model import AttLayer
import sys

precision = tf.keras.metrics.Precision()
recall = tf.keras.metrics.Recall()
AUC = tf.keras.metrics.AUC()

if __name__=="__main__":
    filename = sys.argv[1]
    pcf = float(sys.argv[2])
    ids, seq = preprocess(filename)
    model = load_model("model/general/general_model.h5",
                       custom_objects={"AttLayer": AttLayer, "Precision": precision, "Recall": recall, "AUC": AUC},
                       compile=False)
    model.compile(loss="binary_crossentropy", optimizer="adam", metrics=['accuracy', precision, recall])
    seq1, seq2, seq3, seq4, seq5, seq6, seq7, seq8, seq9, seq10 = seq[:, :3000], seq[:, 3000:6000], \
                                                    seq[:, 6000:9000], seq[:, 9000:12000], \
                                                    seq[:, 12000:15000], seq[:, 15000:18000], \
                                                    seq[:, 18000:21000], seq[:, 21000:24000], \
                                                    seq[:, 24000:27000], seq[:, 27000:30000]
    pred = model.predict([seq1, seq2, seq3, seq4, seq5, seq6, seq7, seq8, seq9, seq10])
    fw = open('predicting_results.csv', 'w+')
    for i in range(len(pred)):
        if float(pred[i]) > pcf:
            fw.write(ids[i] + ',' + 'H' +'\n')
        else:
            fw.write(ids[i] + ',' + 'N' + '\n')
    fw.close()
