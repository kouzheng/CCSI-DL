import itertools
import numpy as np
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from Bio import SeqIO

def sentence2word(str_set):
    word_seq = []
    for sr in str_set:
        sr = ''.join(sr)
        tmp = []
        for i in range(len(sr)-1):
            if 'N' in sr[i:i + 2]:
                tmp.append('null')
            else:
                tmp.append(sr[i:i + 2])
        word_seq.append(' '.join(tmp))
    return word_seq


def word2num(wordseq, tokenizer, MAX_LEN):
    sequences = tokenizer.texts_to_sequences(wordseq)
    numseq = pad_sequences(sequences, maxlen=MAX_LEN, padding='post')
    return numseq


def sentence2num(str_set, tokenizer, MAX_LEN):
    wordseq = sentence2word(str_set)
    numseq = word2num(wordseq, tokenizer, MAX_LEN)
    return numseq


def get_tokenizer():
    f = ['A', 'C', 'G', 'T']
    c = itertools.product(f, f)
    res = []
    for i in c:
        temp = i[0] + i[1]
        res.append(temp)
    res = np.array(res)
    NB_WORDS = 17
    tokenizer = Tokenizer(num_words=NB_WORDS, lower=False)
    tokenizer.fit_on_texts(res)
    acgt_index = tokenizer.word_index
    acgt_index['null'] = 0
    return tokenizer

def get_seq(seq, MAX_LEN):
    tokenizer = get_tokenizer()
    print(tokenizer.word_index)
    X = sentence2num(seq, tokenizer, MAX_LEN)
    return X

def preprocess(filename):
    seq_id = []
    seq_data = []
    file_path = "fasta/%s" % filename
    for record in SeqIO.parse(file_path, "fasta"):
        if 'complete genome' in record.description:
            seq_id.append(record.id)
            seq_data.append(list(record.seq))

    seq_data = np.array(seq_data)
    seq_preprocessed = get_seq(seq_data, 30000)
    return seq_id, seq_preprocessed
